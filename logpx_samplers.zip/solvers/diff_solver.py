import torch
import torch.nn as nn
import torch.nn.functional as F
from tqdm import tqdm
import os
import json
import pickle
import numpy as np

from .solver import Solver

# =================================================================
# DS_Solver: 샘플링(추론) 전용 클래스
# =================================================================
class DS_Solver(Solver):
    def __init__(
        self,
        model_fn,
        noise_schedule,
        algorithm_type="data_prediction",
        learned_params_path=None,
        steps=10
    ):
        super().__init__(model_fn, noise_schedule, algorithm_type)
        assert self.algorithm_type in ["data_prediction", "noise_prediction"], \
            "DS_Solver only supports 'data_prediction' or 'noise_prediction'"
        
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

        if learned_params_path and os.path.exists(learned_params_path):
            self._load_learned_params(learned_params_path)
        else:
            self._initialize_default_params(steps)

        self._timesteps_cache = None
        self._solver_matrix_cache = None

    def _initialize_default_params(self, steps):
        self.steps = steps
        self.r_params = nn.Parameter(torch.ones(steps, device=self.device), requires_grad=True)
        self.c_matrix = nn.Parameter(torch.zeros(steps, steps - 1, device=self.device), requires_grad=True)

    def _load_learned_params(self, path):
        print(f"DS-Solver: Loading learned parameters from {path}")
        with open(path, 'rb') as f:
            data = pickle.load(f)
        params = data.get('parameters', data)
        
        self.steps = len(params.get('timesteps', [0] * (10 + 1))) - 1
        self.r_params = nn.Parameter(torch.tensor(params['r_params'], device=self.device, dtype=torch.float32), requires_grad=False)
        self.c_matrix = nn.Parameter(torch.zeros(self.steps, self.steps - 1, device=self.device), requires_grad=False)
        if 'c_params' in params:
            for i, c_param in enumerate(params['c_params']):
                if i + 1 < self.steps:
                    c_tensor = torch.tensor(c_param, device=self.device, dtype=torch.float32)
                    self.c_matrix.data[i + 1, :len(c_tensor)] = c_tensor
        print(f"DS-Solver: Loaded parameters for {self.steps} steps.")

    def parameters(self):
        return [self.r_params, self.c_matrix]

    def get_timesteps(self):
        if self._timesteps_cache is None:
            with torch.no_grad():
                time_deltas = F.softmax(self.r_params, dim=0)
                timesteps = torch.cumsum(time_deltas, dim=0)
                self._timesteps_cache = torch.cat([torch.zeros(1, device=self.device), timesteps], dim=0)
        return self._timesteps_cache

    def get_solver_matrix(self):
        if self._solver_matrix_cache is None:
            with torch.no_grad():
                M = torch.zeros(self.steps, self.steps, device=self.device); M[0, 0] = 1.0
                for i in range(1, self.steps):
                    M[i, :i] = self.c_matrix[i, :i]; M[i, i] = 1.0 - M[i, :i].sum()
                self._solver_matrix_cache = M
        return self._solver_matrix_cache
        
    def invalidate_cache(self):
        self._timesteps_cache = None
        self._solver_matrix_cache = None

    def scale_timesteps(self, timesteps_in_0_1):
        t_0 = 1. / self.noise_schedule.total_N
        t_T = self.noise_schedule.T
        return t_0 + timesteps_in_0_1 * (t_T - t_0 - 1e-4)

    def _ds_update_step(self, x, s, t, combined_x0):
        alpha_s, sigma_s = self.noise_schedule.marginal_alpha(s), self.noise_schedule.marginal_std(s)
        alpha_t, sigma_t = self.noise_schedule.marginal_alpha(t), self.noise_schedule.marginal_std(t)
        omega_s = alpha_s / (sigma_s + 1e-8)
        omega_t = alpha_t / (sigma_t + 1e-8)
        return (sigma_t / sigma_s) * x + sigma_t * (omega_t - omega_s) * combined_x0

    def _dpm_noise_update_step(self, x_t, t_current, t_next, noise_pred):
        alpha_s, alpha_t = self.noise_schedule.marginal_alpha(t_current), self.noise_schedule.marginal_alpha(t_next)
        sigma_s, sigma_t = self.noise_schedule.marginal_std(t_current), self.noise_schedule.marginal_std(t_next)
        return (alpha_t / alpha_s) * x_t - (sigma_t * (alpha_s / alpha_t) - sigma_s) * noise_pred

    @torch.no_grad()
    def sample(self, x, steps=None, **kwargs):
        if steps is not None and steps != self.steps:
            print(f"Warning: DS-Solver trained for {self.steps} steps, but {steps} requested.")
        
        base_timesteps = self.get_timesteps()
        scaled_timesteps = self.scale_timesteps(base_timesteps)
        timesteps = torch.flip(scaled_timesteps, [0])
        solver_matrix = self.get_solver_matrix()
        
        model_output_buffer = []
        x_t = x
        
        for i in tqdm(range(self.steps), disable=os.getenv("TQDM_DISABLE", "true")):
            t_current, t_next = timesteps[i], timesteps[i+1]
            model_output = self.model_fn(x_t, t_current)
            model_output_buffer.append(model_output)
            output_stack = torch.stack(model_output_buffer)
            weights = solver_matrix[i, :i+1]
            combined_output = torch.einsum('n,n...->...', weights.to(output_stack.dtype), output_stack)
            
            if self.algorithm_type == "data_prediction":
                x_t = self._ds_update_step(x_t, t_current, t_next, combined_output)
            else:
                x_t = self._dpm_noise_update_step(x_t, t_current, t_next, combined_output)
        return x_t
    
    def print_learned_params(self):
        print("\n--- Loaded DS-Solver Parameters ---")
        timesteps = self.get_timesteps().cpu().numpy()
        print(f"Learned Timesteps ({len(timesteps)-1} steps):")
        for i, t in enumerate(timesteps):
            print(f"  t_{i}: {t:.4f}")

# =================================================================
# DSTrainer: DS_Solver 학습 전용 클래스
# =================================================================
class DSTrainer:
    def __init__(self, model, algorithm_type="data_prediction", target_steps=10, reference_steps=10):
        self.model = model
        self.algorithm_type = algorithm_type
        self.target_steps = target_steps
        self.reference_steps = reference_steps
        self.device = model.device
        self._init_trainer()

    def _init_trainer(self):
        dummy_conds = [0] if type(self.model).__name__ == 'DiT' else [""]
        train_model_fn, train_noise_schedule, _ = self.model.get_model_fn(
            pos_conds=dummy_conds, guidance_scale=1.0, seeds=[42]
        )
        self.solver = DS_Solver(
            train_model_fn, train_noise_schedule, self.algorithm_type, 
            learned_params_path=None, steps=self.target_steps
        )

    def train(self, num_samples, batch_size, save_path, lr=0.01, weight_decay=0.0):
        try:
            from lion_pytorch import Lion
            optimizer = Lion(self.solver.parameters(), lr=lr, weight_decay=weight_decay)
            print(f"DSTrainer: Using Lion optimizer with lr={lr} to train BOTH r_params and c_matrix.")
        except ImportError:
            raise ImportError("Lion optimizer not found. Please install it by running: pip install lion-pytorch")
        
        num_iterations = max(1, num_samples // batch_size)
        pbar = tqdm(range(num_iterations), desc="Training DS-Solver")
        
        for iteration in pbar:
            x_batch = torch.randn(batch_size, self.model.pipe.transformer.config.in_channels, self.model.pipe.transformer.config.sample_size, self.model.pipe.transformer.config.sample_size, device=self.device, dtype=torch.float32)
            ref_trajectory = self._generate_reference_trajectory(x_batch, self.reference_steps)

            optimizer.zero_grad()
            loss = self._compute_loss(x_batch, ref_trajectory, iteration) # Pass iteration number
            if torch.isnan(loss):
                # NaN이 발생하면 루프를 중단
                print(f"\n!!! Loss is NaN at iteration {iteration + 1}. Halting training. !!!")
                break
            
            loss.backward()
            torch.nn.utils.clip_grad_norm_(self.solver.parameters(), 1.0)
            optimizer.step()
            pbar.set_postfix({'loss': f'{loss.item():.4f}'})
        
        if not torch.isnan(loss):
            print(f"\nTraining completed! Final loss: {loss.item():.4f}")
            self._save_learned_params(save_path)

    def _get_learned_trajectory(self, x_batch, iteration):
        self.solver.invalidate_cache()
        with torch.enable_grad():
            time_deltas = F.softmax(self.solver.r_params, dim=0)
            base_timesteps_0_1 = torch.cat([torch.zeros(1, device=self.device), torch.cumsum(time_deltas, dim=0)], dim=0)
            timesteps = self.solver.scale_timesteps(base_timesteps_0_1)
            timesteps = torch.flip(timesteps, [0]) # 역방향
            
            M = torch.zeros(self.solver.steps, self.solver.steps, device=self.device); M[0, 0] = 1.0
            
            # --- 디버깅 로그: 대각 행렬 값 직접 출력 ---
            print(f"\n--- Verifying Solver Matrix Diagonals (Iteration {iteration + 1}) ---")
            for i in range(1, self.solver.steps):
                c_vals = self.solver.c_matrix[i, :i]
                c_sum = c_vals.sum()
                M[i, :i] = c_vals
                M[i, i] = 1.0 - c_sum
                print(f"  [Step {i}] c_sum: {c_sum.item():.6f}, Diagonal M[{i},{i}]: {M[i, i].item():.6f}")
                if M[i, i].item() < 0:
                    print(f"  !!!!!! WARNING: Negative diagonal detected at Step {i} !!!!!!")
            print("--- Verification End ---")

            solver_matrix = M
            
            trajectory = [x_batch.clone()]
            model_output_buffer = []
            x_t = x_batch
            for i in range(self.solver.steps):
                t_current, t_next = timesteps[i], timesteps[i+1]
                model_output = self.solver.model_fn(x_t, t_current)
                model_output_buffer.append(model_output)
                output_stack = torch.stack(model_output_buffer)
                weights = solver_matrix[i, :i+1]
                combined_output = torch.einsum('n,n...->...', weights.to(output_stack.dtype), output_stack)
                if self.solver.algorithm_type == "data_prediction":
                    x_t = self.solver._ds_update_step(x_t, t_current, t_next, combined_output)
                else:
                    x_t = self.solver._dpm_noise_update_step(x_t, t_current, t_next, combined_output)
                
                if torch.isnan(x_t).any():
                    print(f"!!! NaN detected in x_t after update at Step {i} in Iteration {iteration + 1} !!!")
                    break
                
                trajectory.append(x_t.clone())
        return timesteps, trajectory

    @torch.no_grad()
    def _generate_reference_trajectory(self, x_batch, reference_steps):
        #from .euler_solver import Euler_Solver
        #euler = Euler_Solver(self.solver.model_fn, self.solver.noise_schedule, self.solver.algorithm_type)
        
        t_0 = 1. / self.solver.noise_schedule.total_N
        t_T = self.solver.noise_schedule.T
        timesteps = torch.linspace(t_T, t_0, reference_steps + 1).to(self.device)

        trajectory = [x_batch.clone()]
        x_t = x_batch
        for i in range(reference_steps):
            t_current, t_next = timesteps[i], timesteps[i+1]
            model_output = self.solver.model_fn(x_t, t_current)
            
            lambda_current = self.solver.noise_schedule.marginal_lambda(t_current)
            lambda_next = self.solver.noise_schedule.marginal_lambda(t_next)
            h = lambda_next - lambda_current
            sigma_next = self.solver.noise_schedule.marginal_std(t_next)
            signal_rate_next = self.solver.noise_schedule.marginal_alpha(t_next)
            
            x_t = ( (sigma_next/self.solver.noise_schedule.marginal_std(t_current))*x_t + (-signal_rate_next*torch.expm1(-h))*model_output )
            trajectory.append(x_t.clone())
        return trajectory

    def _compute_loss(self, x_batch, ref_trajectory, iteration):
        learned_timesteps, learned_trajectory = self._get_learned_trajectory(x_batch, iteration)
        
        if len(learned_trajectory) <= 1 or (learned_trajectory[-1]).isnan().any():
            return torch.tensor(float('nan'), device=self.device)

        total_mse_loss = 0.0
        ref_len = len(ref_trajectory)
        
        learned_timesteps_forward = torch.flip(learned_timesteps, [0])
        
        for i in range(1, len(learned_trajectory)):
            learned_state = learned_trajectory[i]
            current_t = learned_timesteps_forward[i]
            t_0 = 1. / self.solver.noise_schedule.total_N; t_T = self.solver.noise_schedule.T
            ratio = (current_t - t_0) / (t_T - t_0)
            ref_idx = min(ref_len - 1, int(ratio * (ref_len - 1)))
            ref_state = ref_trajectory[ref_idx].expand_as(learned_state)
            total_mse_loss += F.mse_loss(learned_state, ref_state)
            
        mse_loss = total_mse_loss / self.solver.steps
        huber_loss = F.smooth_l1_loss(learned_trajectory[-1], ref_trajectory[-1].expand_as(learned_trajectory[-1]))
        return mse_loss + huber_loss

    def _save_learned_params(self, path):
        params_to_save = {
            'parameters': {
                'timesteps': self.solver.get_timesteps().detach().cpu().numpy(),
                'solver_matrix': self.solver.get_solver_matrix().detach().cpu().numpy(),
                'r_params': self.solver.r_params.detach().cpu().numpy(),
                'c_params': [self.solver.c_matrix[i, :i].detach().cpu().numpy() for i in range(1, self.solver.steps)]
            }
        }
        with open(path, 'wb') as f:
            pickle.dump(params_to_save, f)
        print(f"Learned parameters saved to {path}")