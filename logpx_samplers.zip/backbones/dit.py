import torch
import numpy as np
from diffusers import DiTPipeline
from typing import Optional, List, Tuple, Union
from .backbone import Backbone
from solvers.common import NoiseScheduleVP, model_wrapper
from PIL import Image

class DiT(Backbone):
    def __init__(
        self,
        device: Union[str, torch.device] = 'cuda',
        dtype: torch.dtype = torch.bfloat16,
        model_id: str = "facebook/DiT-XL-2-256"
    ):
        super().__init__()
        self.device = torch.device(device)
        self.dtype = dtype

        self.pipe = DiTPipeline.from_pretrained(model_id, torch_dtype=dtype)
        self.pipe.to(self.device)

        for submod in (self.pipe.vae, self.pipe.transformer):
            submod.to(dtype)
            submod.eval()

    @torch.inference_mode()
    def prepare_noise(
        self, seeds: List[int],
    ) -> torch.Tensor:
        C = self.pipe.transformer.config.in_channels
        height = width = self.pipe.transformer.config.sample_size
        shape = (C, height, width)
        noise = np.stack([np.random.RandomState(s).randn(*shape) for s in seeds], axis=0)
        return torch.from_numpy(noise).to(self.device).to(torch.float32)

    @torch.inference_mode()
    def decode_vae(
        self,
        latents: torch.Tensor,
    ) -> List[Image.Image]:
        lat = (latents / self.pipe.vae.config.scaling_factor).to(self.dtype)
        samples = self.pipe.vae.decode(lat).sample
        samples = (samples / 2 + 0.5).clamp(0, 1)
        samples = samples.cpu().permute(0, 2, 3, 1).float().numpy()
        return self.pipe.numpy_to_pil(samples)

    # <<< 수정된 부분: 함수 전체를 감싸던 @torch.inference_mode() 데코레이터를 제거 >>>
    def get_model_fn(
        self,
        pos_conds = [0],
        guidance_scale: float = 4.0,
        seeds: Union[int, None] = None,
        condition=None,
        unconditional_condition=None
    ) -> Tuple[callable, NoiseScheduleVP, torch.Tensor]:
        if condition is not None:
             pos_conds = condition
        
        batch_size = len(pos_conds)
        if seeds is None:
            seeds = [42 for _ in range(batch_size)]
        assert len(seeds) == batch_size

        # <<< 수정된 부분: 무거운 연산만 개별적으로 no_grad 처리 >>>
        with torch.no_grad():
            latents = self.prepare_noise(seeds)
        
        noise_schedule = NoiseScheduleVP(schedule="discrete", betas=self.pipe.scheduler.betas, dtype=self.dtype)
        
        # <<< 수정된 부분: 그래디언트 추적이 필요한 텐서 생성은 no_grad 밖에서 수행 >>>
        class_labels = torch.tensor(pos_conds, device=self.device).reshape(-1)
        class_null = torch.tensor([1000] * len(pos_conds), device=self.device)

        def inner_model_fn(x, t, cond, **kwargs):
            x = x.to(kwargs['dtype'])
            # 추론 시에는 no_grad가 적용되지만, 학습 시에는 적용되지 않음
            with torch.no_grad() if not torch.is_grad_enabled() else torch.enable_grad():
                 pred = self.pipe.transformer(x, timestep=t, class_labels=cond).sample
            pred = pred[:, :x.shape[1]]
            return pred
        
        model_fn = model_wrapper(
                inner_model_fn,
                noise_schedule,
                model_type="noise",
                guidance_type="classifier-free",
                model_kwargs={"dtype": self.dtype},
                condition=class_labels,
                unconditional_condition=class_null,
                guidance_scale=guidance_scale,
        )
        return model_fn, noise_schedule, latents